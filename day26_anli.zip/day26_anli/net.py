from torch import nn
import torch


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(2304, 1296),
            nn.PReLU(),
            nn.Linear(1296, 512),
            # nn.ReLU(),
            nn.PReLU(),
            nn.Linear(512, 256),
            # nn.ReLU(),
            nn.PReLU(),
            nn.Linear(256, 128),
            # nn.ReLU(),
            nn.PReLU(),
            nn.Linear(128, 64),
            # nn.ReLU(),
            nn.PReLU(),
            nn.Linear(64, 32),
            # nn.ReLU(),
            nn.PReLU(),
            nn.Linear(32, 16),
            nn.PReLU(),
            nn.Linear(16, 3)
        )
        # self.softmax = nn.Softmax(dim=0)

    def forward(self, x):
        x = self.fc(x)
        # out = self.softmax(x)
        return x




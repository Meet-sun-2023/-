
import os.path
import tqdm
from dataset import MNISTDataset
from torch.utils.data import DataLoader
from net import Net
from torch import nn
import torch
from torch.utils.tensorboard import SummaryWriter


device = "cuda:0" if torch.cuda.is_available() else "cpu"
best_path = "weights/best.pt"


class Trainer:
    def __init__(self):
        # 1.准备数据
        train_set = MNISTDataset(isTrain=True)
        self.train_loader = DataLoader(dataset=train_set, batch_size=100, shuffle=True)

        # 2.创建模型
        net = Net()
        self.net = net
        # 加载参数
        if os.path.exists(best_path):
            net.load_state_dict(torch.load(best_path))
        net.to(device)
        # 3.确定损失函数
        self.loss_fn = nn.CrossEntropyLoss()
        # self.loss_fn = nn.MSELoss()
        # 优化器
        # self.opt = torch.optim.SGD(net.parameters(), lr=0.03, momentum=0.5)
        self.opt = torch.optim.Adam(net.parameters())
        self.writer = SummaryWriter("logs")

    def train(self, epoch):
        best_acc = 0.924
        sum_loss = 0
        sum_acc = 0
        for img_vector, target in tqdm.tqdm(self.train_loader, desc="train",
                                            total=len(self.train_loader)):
            # 模型
            img_vector, target = img_vector.to(device), target.to(device)
            pred_out = self.net(img_vector)
            # 模型的前向传播得到pred_out与target标签求损失
            loss = self.loss_fn(pred_out, target)
            # 梯度清零
            self.opt.zero_grad()
            # 反向传播求梯度
            loss.backward()
            # 更新参数
            self.opt.step()
            sum_loss += loss.item()

            pred_cls = torch.argmax(pred_out, dim=1)
            # target_cls = torch.argmax(target, dim=1)
            equal = torch.eq(pred_cls, target).to(torch.float32)
            acc = torch.mean(equal)
            sum_acc += acc.item()

        train_avg_loss = sum_loss / len(self.train_loader)
        train_avg_acc = sum_acc / len(self.train_loader)
        print(f"\n第{epoch}轮训练结果：损失值为{train_avg_loss}，精确度为{train_avg_acc}")
        self.writer.add_scalars("loss", {"train_avg_loss": train_avg_loss}, epoch)
        self.writer.add_scalars("acc", {"train_avg_acc": train_avg_acc}, epoch)

        if train_avg_acc > best_acc:
            best_acc = train_avg_acc
            best_path = "weights/best.pt"
            if os.path.exists(best_path):
                os.remove(best_path)
                torch.save(self.net.state_dict(), f"weights/best.pt")
            else:
                torch.save(self.net.state_dict(), f"weights/best.pt")

    def run(self):
        for epoch in range(100):
            self.train(epoch)


if __name__ == '__main__':
    trainer = Trainer()
    trainer.run()


from PIL import Image
import os

# 设置统一的目标尺寸
target_size = (48, 48)

# 指定雏菊数据集的目录
dataset_directory = './flowers/train/sunflower'

# 创建一个新的目录用于存储调整大小后的图片
resized_directory = './mnist_new/train/sunflower'
# os.makedirs(resized_directory, exist_ok=True)

# 循环处理每张图片
for filename in os.listdir(dataset_directory):
    if filename.endswith(".jpg"):  # 假设所有图片文件都是 jpg 格式
        filepath = os.path.join(dataset_directory, filename)

        # 打开图片
        img = Image.open(filepath)

        # 调整大小
        img_resized = img.resize(target_size)

        # 保存调整大小后的图片到新目录
        resized_filepath = os.path.join(resized_directory, filename)
        img_resized.save(resized_filepath)

print("图片调整大小完成，保存在:", resized_directory)

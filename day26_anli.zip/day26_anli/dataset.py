import glob
import os.path
import cv2
import torch
from torch.utils.data import Dataset
# one——hot映射
key_dict = {"daisy": 0, "rose": 1, "sunflower": 2}


class MNISTDataset(Dataset):
    def __init__(self, root=r"D:\projects\day26_anli\mnist_new", isTrain=True):
        super().__init__()
        type = "train" if isTrain else "test"
        # 方式二
        self.data = []
        path = os.path.join(root, type, "*", "*")
        img_paths = glob.glob(path)
        for img_path in img_paths:
            img_infos = img_path.rsplit("\\", maxsplit=2)
            label = key_dict[img_infos[-2]]
            self.data.append((img_path, label))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # 取出图片路径与对应的标签
        img_path, label = self.data[idx]
        # 将img_path读取出来转换成张量
        # 224 * 224 * 3
        img = cv2.imread(img_path)
        # 224 * 224
        if img is None:
            print("img is None")
        else:
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # 归一化处理
            # h, w
            img_gray = img_gray/255
            img_gray = torch.tensor(img_gray, dtype=torch.float32)

            img_vector = torch.flatten(img_gray)
            # label处理

            # one_hot = torch.zeros(3)
            # one_hot[label] = 1
            target = torch.tensor(int(label))
            return img_vector, target


if __name__ == '__main__':
    dataset = MNISTDataset()
    print(dataset[0])


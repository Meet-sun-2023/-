import glob
import os.path
from net import Net
from torch import nn
import torch
import cv2

best_path = "weights/best.pt"
key_dict = {0: "daisy", 1: "rose", 2: "sunflower"}
device = "cuda:0" if torch.cuda.is_available() else "cpu"
# 1.加载数据
root = "./images/rose"
target = root.rsplit("/")[-1]
path = os.path.join(root, '*')
paths = glob.glob(path)
img_vectors = []
for path in paths:
    img = cv2.imread(path)
    img = cv2.resize(img, dsize=(48, 48))
    # 转换为灰度图
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 归一化
    img_gray = img_gray / 255
    # 转换为张量
    img_gray = torch.tensor(img_gray, dtype=torch.float32)
    # 展平
    img_vector = torch.flatten(img_gray)
    img_vectors.append(img_vector)
# img_vectors = torch.tensor(img_vectors)
# 2.调用模型作预测
net = Net()
if os.path.exists(best_path):
    net.load_state_dict(torch.load(best_path))
net.to(device)
# loss_fn = nn.MSELoss()

# 开始预测
for img_vector in img_vectors:
    img_vector = img_vector.to(device)
    predict = net(img_vector)
    # one-hot 编码
    predict_idx = torch.argmax(predict)
    print(f"这张图片是：{key_dict[int(predict_idx)]}", end=" ")
    if key_dict[int(predict_idx)] == target:
        print("分类成功！")
    else:
        print("分类失败！")


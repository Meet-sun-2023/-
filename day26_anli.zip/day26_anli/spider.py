import re
import threading
import time
from threading import Thread, Lock
import requests
# 关键字
keyword = '轿车'
# 存放的目录
img_dir = 'images/cars/'
# 每一页的图片数量
page_num = 30
# 爬取的地址
urls = [f'https://image.baidu.com/search/flip?tn=baiduimage&ie=utf-8&word="{keyword}"&pn={30 * index}'
        for index in range(page_num)]
# 统计图片数量
lock = Lock()
image_count = 0


class Spider(Thread):
    def __init__(self, name):
        super(Spider, self).__init__()
        self.name = name
    """
        下载数据
        1. headers
        2. 发起请求
    """

    def down_load(self, url):
        global image_count
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'
        }
        result = requests.get(url, timeout=10, headers=headers)
        """
        # print(result.text)
        # .除\n（换行符）之外的任意字符
        # *匹配0 - 无穷次
        # ?非贪婪模式（一旦拿到数据直接返回，不再向下匹配）
        
        "objURL":"https://imgx.xiawu.com/xzimg/i4/i2/TB1FDR2FVXXXXXMXpXXXXXXXXXX_%21%210-item_pic.jpg",
        'https://image.baidu.com/search/flip?tn=baiduimage&ie=utf-8&word="草莓"&pn=0'
        """
        # 需要匹配包括换行符在内的所有字符。这时可以使用re.S标志
        image_urls = re.findall('"objURL":"(.*?)",', result.text, re.S)
        print(image_urls)
        """
        请求图片
        保存图片
         图片命名 序号+格式
        """
        for image_url in image_urls:
            try:
                image_name = str(int(time.time() * 1000000)) + '.jpg'
                image_url = image_url.strip('"')
                image_url = image_url.strip("'")
                pic = requests.get(image_url, timeout=7)
                img_path = img_dir + image_name
                fp = open(img_path, 'wb')
                fp.write(pic.content)
                fp.close()
                image_count += 1
                name = threading.current_thread().name
                print(f'线程:{name} {image_name}保存成功 第{image_count}张')
            except:
                print(f'{image_name}出错啦')

    def run(self):
        global urls
        while True:
            lock.acquire()
            if len(urls) == 0:
                print('.............没有数据啦.............')
                lock.release()
                return
            """
            在Python中，列表是线程不安全的数据结构，因为它不是线程安全的。
            这意味着，在多线程环境中，如果多个线程同时对同一个列表进行操作，可能会导致竞态条件和数据不一致问题
            """
            url = urls[0]
            # 这里多一句代码就会演示出问题 出现线程安全问题
            # print('--------')
            del urls[0]
            name = threading.current_thread().name
            print(f'{name} 获取了数据{url}')
            # time.sleep(0.1)
            lock.release()
            self.down_load(url)


if __name__ == '__main__':
    """
        输入需要爬取的页数
        1. 输入需要爬取的页数
        2. 每页返回60个数据
        3. 请求数据
    """
    # page_num = int(input('请输入需要爬取的页数:'))
    # pn  页数
    # 0  第1页
    # 20 第2页
    # 40 第3页
    t1 = time.time()
    queue = []
    for index in range(3):
        spider = Spider(f'th-{index}')
        spider.start()
        queue.append(spider)
    for spider in queue:
        spider.join()
    t2 = time.time()
    # 4个线程
    # 结束用时:76.23213601112366
    # 1个线程
    print(f'结束用时:{t2-t1}')